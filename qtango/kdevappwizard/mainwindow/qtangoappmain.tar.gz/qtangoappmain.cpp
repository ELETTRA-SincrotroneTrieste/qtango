%{CPP_TEMPLATE}

#include "%{APPNAMELC}.h"
#include <qtango.h>

%{APPNAME}::%{APPNAME}(QWidget *parent) : QMainWindow(parent)
{
	ui.setupUi(this);
}

%{APPNAME}::~%{APPNAME}()
{
}    
