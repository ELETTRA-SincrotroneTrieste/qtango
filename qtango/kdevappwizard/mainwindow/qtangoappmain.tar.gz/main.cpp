%{CPP_TEMPLATE}

#include "%{APPNAMELC}.h"
#include <tutil.h>  /* for setLoggingTarget() */
/* the following two are used to register the application to the window manager */
#include <X11/Xlib.h>
#include <QX11Info>

#include <elettracolors.h> /* to set elettra/booster/fermi palette */

#include <TApplication>
#include <TSplashScreen>
// #include <EStyleLoader> /* see comment below */

#define CVSVERSION "$Name: $"

int main( int argc, char ** argv ) {

    /* introduced in version 3.1. To retrieve the version:
	 * 1. on the executable, execute `strings' and grep with "\$Name"
	 * 2. call qApp->applicationVersion
	 * 3. TApplication exports "version" on the DBus system.
	 */
	const char *cvs_version = CVSVERSION;
	/* Create TApplication */
    TApplication a( argc, argv );
	/* make the version available through QApplication::instance()->applicationVersion() 
	 * and through the DBus message bus.
	 */
	a.setApplicationVersion(cvs_version);
    /* change "fermi" into "booster" or "elettra" to set booster/elettra palettes */
    a.setPalette(EPalette("fermi"));
	
	a.setApplicationName("%{APPNAME}");
	
	/* comment the following properties if you are not interested in them.
	 * They are exported through QApplication and are available from any
	 * QTango widget by right clicking and executing the "Info" action
	 * of the menu.
	 */
	a.setProperty("author", "");
    a.setProperty("mail", "");
    a.setProperty("phone", "375-XXXX");
    a.setProperty("office", "T2PT0XX");
	a.setProperty("hwReferent", ""); /* name of the referent that provides the device server */
	
    TUtil::instance()->setLoggingTarget(argv[0]);
	
	/* load the style sheet for QTango application. 
	 * The file is read from the "${INSTALL_ROOT}/share/qtango/stylesheets/qtango.css"
	 * file. You can load a custom stylesheet by exporting the environment variable 
	 * "QTANGO_STYLESHEET" and setting it to a different path.
	 * Moreover, you can construct EStyleLoader with a file name as argument, to ignore
	 * the installed "${INSTALL_ROOT}/share/qtango/stylesheets/qtango.css" and the value
	 * of the environment variable.
	 *
	 * This does not work as expected in Qt version 4.4. Uncomment the following two lines
	 * when solved.
	 */
//    EStyleLoader sLoader;
//    a.setStyleSheet(sLoader.styleSheet());

	/* splash screen */
    TSplashScreen splash;

    %{APPNAME} mw;
    if (argc > 1)
        mw.setWindowTitle(QApplication::arguments()[1].split('/').last());
    else
        mw.setWindowTitle("%{APPNAME}");

    mw.show();
	/* hide splash screen */
    splash.finish(&mw);

    /* register to window manager */
    Display *disp = QX11Info::display();
    Window root_win = (Window) mw.winId();
    XSetCommand(disp, root_win, QApplication::argv(), QApplication::argc());
	
    return a.exec();
}
