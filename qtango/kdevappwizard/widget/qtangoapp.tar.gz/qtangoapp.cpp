%{CPP_TEMPLATE}

#include "%{APPNAMELC}.h"
#include <qtango.h>

%{APPNAME}::%{APPNAME}(QWidget *parent) : QWidget(parent)
{
	ui.setupUi(this);
}

%{APPNAME}::~%{APPNAME}()
{
}    
