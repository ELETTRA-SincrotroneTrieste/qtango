%{H_TEMPLATE}

#ifndef %{APPNAMELC}_H
#define %{APPNAMELC}_H

#include "ui_%{APPNAMELC}.h"

class %{APPNAME}: public QWidget
{
    Q_OBJECT

public:
    %{APPNAME}(QWidget * =NULL);
    ~%{APPNAME}();

private:
    Ui::%{APPNAME} ui;

};


#endif
